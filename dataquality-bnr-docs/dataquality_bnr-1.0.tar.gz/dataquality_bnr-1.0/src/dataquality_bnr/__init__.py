import os

os.environ["SPARK_VERSION"] = "2.4.0"